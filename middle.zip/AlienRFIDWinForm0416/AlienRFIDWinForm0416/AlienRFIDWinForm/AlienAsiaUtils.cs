﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlienRFIDWinForm
{
    class AlienAsiaUtils
    {
        public static string removePrefix(string msg)
        {
            if (msg == null)
                return null;

            int idx = msg.IndexOf(" ");
            if ((idx == -1) || (idx == msg.Length))
                return msg;
            else
                return msg.Substring(idx + 1);
        }
    }
}
