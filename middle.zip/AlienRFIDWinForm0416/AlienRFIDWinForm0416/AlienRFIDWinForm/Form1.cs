﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using dbControl;

using System.Configuration;

using nsAlienRFID2;
using System.Threading;
//0402
namespace AlienRFIDWinForm
{
	public partial class Form1 : Form
	{
		public static clsReader mReader;

		bool mbDisposing = false;
		public static CAlienServer mServer;
		TagInfo[] aTags;
		string sServerIP = ConfigurationManager.ConnectionStrings["Server_IP"].ConnectionString;
		Dictionary<string, string> InBoxTag = new Dictionary<string, string>();

		public Form1()
		{
			InitializeComponent();

			int readerIp_cnt = ConfigurationManager.AppSettings.Count;
			string[] strip = new string[readerIp_cnt];

			for (int i = 0; i < readerIp_cnt; i++)
			{
				strip[i] = ConfigurationManager.AppSettings.Get(i);
				Console.WriteLine(strip[i] + "테스트");
				try
				{
					mReader = new clsReader(true);
					mReader.InitOnNetwork(strip[i], 23);
					mReader.Connect();
					if (mReader.Login("alien", "password"))
					{
						Console.WriteLine("Reader Connected");

						mReader.FactorySettings();
						mReader.RFLevel = 300;
						mReader.AntennaSequence = "0 1 2 3";

						// NotifyMode 
						mReader.NotifyAddress = sServerIP + ":4000";
						mReader.NotifyFormat = "Text";
						mReader.NotifyHeader = "off";
						mReader.NotifyTrigger = "true";
						mReader.NotifyMode = "on";
						mReader.AutoMode = "on";
						// NotifyMode

						// TagStreamMode 
						//mReader.TagStreamAddress = "192.168.1.111:4000";
						//mReader.TagStreamFormat = "Text";
						//mReader.TagStreamMode = "on";
						//mReader.AutoMode = "on";
						// TagStreamMode 

						mReader.Disconnect();
					}
					else
					{
						MessageBox.Show("리더기가 연결되어 있지 않습니다.");
					}
				}
				catch
				{
					MessageBox.Show("리더기가 연결되어 있지 않습니다.");
				}
			}
			mServer = new CAlienServer(4000, sServerIP, true);
			mServer.ServerMessageReceived += new CAlienServer.ServerMessageReceivedEventHandler(mServer_ServerMessageReceived);
			mServer.StartListening();

			Thread th2 = new Thread(() =>
			{
				while (true)
				{
					//inboxtag dic을 5초 주기로 확인해 현재 시간과 30초 이상의 차이가 있는 상자는 out
					for (int i = 0; i < InBoxTag.Count; i++)
					{
						string endtime = InBoxTag[InBoxTag.Keys.ToList()[i]];
						Console.WriteLine(InBoxTag.Keys.ToList()[i]);
						TimeSpan datediff = (DateTime.Now - Convert.ToDateTime(endtime));
						
						if (datediff.Minutes > 10)
						{
							dbAccess_Insert history_insert = new dbAccess_Insert()
							{
								Query = $"Insert Into ED_LMS.dbo.RFID_Receive_History(MasterSite, SiteGroup, Tag, IOType, OutDateTime, CreateDateTime) Values('ED','A', '{InBoxTag.Keys.ToList()[i]}', 'OUT', '{endtime}', '{endtime}')"
							};
							history_insert.Insert();

							dbAccess_Insert product_update = new dbAccess_Insert()
							{
								Query = $"UPDATE Bin_Product Set OutYN = 1, OutDateTime = getdate() ,InYN = 0, TermTime = CONVERT(NVARCHAR(22), DATEDIFF(minute, '{endtime}', getdate())) + '분', LastModifiedOn = getdate() WHERE Bin_Product.BinCode = '{InBoxTag.Keys.ToList()[i]}'"
							};
							product_update.Insert();

							InBoxTag.Remove(InBoxTag.Keys.ToList()[i]);				
						}
					}
					Thread.Sleep(5000);
				}
			});

			th2.Start();
		}



		void mServer_ServerMessageReceived(string msg)
		{
			if ((mbDisposing) || (msg == null))
				return;

			string s = AlienAsiaUtils.removePrefix(msg);
			AlienUtils.ParseTagList(s, out aTags);

			string tag = "";
			string SysDateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

			try
			{
				foreach (TagInfo t in aTags)
				{
					string hexString;
					if (t.TagID.Length < 24)
					{
						Console.WriteLine(t.TagID + "태그이상");
						continue;
					}

					try
					{
						hexString = t.TagID.Replace(" ", "").Substring(10, 14);
						Console.WriteLine(hexString); //(태그 데이터)hexString = t.TagID.Replace(" ", "").Substring(10,14);

						string ascii = string.Empty;
						for (int i = 0; i < hexString.Length; i += 2)
						{
							String hs = string.Empty;
							hs = hexString.Substring(i, 2);
							int decval = System.Convert.ToInt32(hs, 16);
							char character = System.Convert.ToChar(decval);
							ascii += character;
						}
						tag = ascii;
					}
					catch (Exception ee)
					{
						Console.WriteLine(ee + "Tag, String conversion error");
					}
					Console.WriteLine(tag + "태그" + t.ReadCount);
					SysDateTime = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss").Replace("-", "").Substring(0, 14);


					if (t.ReadCount > 2) //허용한 인지범위 내에서
					{
						if (InBoxTag.ContainsKey(tag)) //이미 있는 상자라면
						{
							InBoxTag[tag] = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
						}
						else //없는 상자라면 추가
						{
							string indatetime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

							InBoxTag.Add(tag, indatetime);

							dbAccess_Insert dbAccess1 = new dbAccess_Insert()
							{
								Query = $"Insert Into ED_LMS.dbo.RFID_Receive_History(MasterSite, SiteGroup, Tag, IOType, InDateTime, CreateDateTime) Values('ED','A', '{tag}', 'IN', '{indatetime}', '{indatetime}')"
							};
							dbAccess1.Insert();

							dbAccess_Insert product_update = new dbAccess_Insert()
							{
								Query = $"UPDATE Bin_Product Set InYN = 1, InDateTime = '{indatetime}', AssignYN = 0 ,OutYN = 0, OutDateTime = null, TermTime = null, LastModifiedOn = getdate() WHERE Bin_Product.BinCode = '{tag}'"
							};
							product_update.Insert();
						}
					}
				}
			}
			catch
			{
				Console.WriteLine("빈tag값");
			}
			Thread.Sleep(4000);
		}

		private void Form1_FormClosed(object sender, FormClosedEventArgs e)
		{
			int readerIp_cnt = ConfigurationManager.AppSettings.Count;
			string[] strip = new string[readerIp_cnt];

			for (int i = 0; i < readerIp_cnt; i++)
			{
				strip[i] = ConfigurationManager.AppSettings.Get(i);
				Console.WriteLine(strip[i] + "테스트");
				try
				{
					mReader = new clsReader(true);
					mReader.InitOnNetwork(strip[i], 23);
					mReader.Connect();
					if (mReader.Login("alien", "password"))
					{
						Console.WriteLine("Reader Connected");

						mReader.FactorySettings();
					}
				}
				catch
				{
					Console.WriteLine("release Error");
				}
			}
		}
	}
}
