﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace dbControl //db엑세스를 편리하게하기 위함
{
	class DBCon
	{
		private static string dbInfo = "Server=10.82.37.71,1433; Uid=dbo_ED_LMS;Pwd=KUhz!0*LNTF8lms1; database=ED_LMS;";
		private static SqlConnection connectedDB;

		public static SqlConnection GetInstance()
		{
			connectedDB = new SqlConnection(dbInfo);

			return connectedDB;
		}
	}

	class dbAccess_Select
	{
		public string Query { get; set; }
		private DataSet ds_dataset;
		//private DataTable dt;

		public DataTable AccSelect()
		{
			try
			{
				DBCon.GetInstance().Open();
			}
			catch
			{
				Console.WriteLine("이미 열려있는 커넥션");
			}


			SqlDataAdapter getData = new SqlDataAdapter(Query, DBCon.GetInstance());
			ds_dataset = new DataSet();
			try
			{
				getData.Fill(ds_dataset);
			}
			catch
			{
				DBCon.GetInstance().Close();
				return null;
			}

			return ds_dataset.Tables[0];
		}
	}

	class dbAccess_Insert
	{
		public string Query { get; set; }

		public void Insert()
		{/*
            try
            {
				SqlConnection insertcon = DBCon.GetInstance();
				SqlCommand cmd_Insert = new SqlCommand(Query, insertcon);

				insertcon.Open();
				cmd_Insert.ExecuteNonQuery();
				insertcon.Close();
			}
            catch
            {
				Console.WriteLine("DB 문제");
            }
			*/
			SqlConnection insertcon = DBCon.GetInstance();

			try
			{
				using (insertcon)
				{
					insertcon.Open();
					SqlCommand cmd = new SqlCommand();
					cmd.Connection = insertcon;
					cmd.CommandText = Query;
					cmd.ExecuteNonQuery();
					insertcon.Close();
				}
			}
			catch (Exception e)
			{
				Console.WriteLine(e + "\n DB에러");
				Console.WriteLine(Query + "\n!!error query!!\n");
				if (insertcon.State == ConnectionState.Open)
				{
					insertcon.Close();
				}
			}
		}

	}
}
