﻿using System.Configuration;
using System.Threading;

using dbControl;

using ED_getPLC_001.Facility_Controll;

using ED_getPLC_001.lib.Focas;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;


//ToolCuttingTime

namespace rdCurrent
{
	class Program
	{
		static void Main(string[] args)
		{
			ED_Fanuc pot1 = new ED_Fanuc();
			#region 데이터
			string[,] currentTool = new string[8, 30];

			/*
			Dictionary<string, int> toolcriterion = new Dictionary<string, int>(); // tool 기준값 저장용도 로직은 FacilityNo+ProgramNo+PTN - KEY   CuttingTime - value
			dbAccess_Select dbAccess1 = new dbAccess_Select()
			{
				Query = $"SET ARITHABORT ON; " +
					$"Select * From dbo.vw_Facility_ToolCuttingTime"//T_02는 공통코드로 fanuc focas 라이브러리를 통해 컨트롤이 가능한 설비를 의미
			};
			foreach (DataRow r in dbAccess1.AccSelect().Rows)
			{
				toolcriterion.Add(r["FacilityNo"].ToString() + r["ProgramNo"].ToString() + r["PTN"].ToString(), int.Parse(r["CuttingTime"].ToString()));
			}*/

			Dictionary<string, string> startcurrent = new Dictionary<string, string>();
			Dictionary<string, string> Programno = new Dictionary<string, string>();
			Dictionary<string, string> Serialno = new Dictionary<string, string>();
			Dictionary<string, string> StartDateTime = new Dictionary<string, string>();
			Elumi_Fanuc fanucfn = new Elumi_Fanuc();

			for (int i = 0; i < ConfigurationManager.AppSettings.Count; i++) //초기값 설정
			{
				pot1.facilityHandle = fanucfn.fanuc_getHandle(ConfigurationManager.AppSettings.Get(i).ToString());
				//5616 + 60*x
				Console.WriteLine("-----------------------------VM0" + (i + 1));

				for (int j = 0; j <= 29; j++)
				{
					int memorystart = 5604 + 60 * j;
					Console.WriteLine("--" + j + "------" + memorystart);
					string PTN = fanucfn.samplePTN(pot1.facilityHandle, (ushort)memorystart, (ushort)(memorystart + 5), 3);

					memorystart += 7234;
					string Current = fanucfn.sample(pot1.facilityHandle, (ushort)memorystart, (ushort)(memorystart + 1), 1);

					Console.WriteLine("PTN : " + PTN + " -- Current : " + Current + "메모리--" + memorystart);
					currentTool[i, j] = Current;
				}
				Focas1.cnc_freelibhndl(pot1.facilityHandle);
			}


			//Console.ReadKey();
			int toolavgchecker = 0;//하루에한번체크하기위함


			#region

			while (true)
			{
				#region 30프로 값을 데이터에서 제어

				if (DateTime.Now.ToString("HHmm") == "0600")
				{
					if (toolavgchecker == 0)
					{
						toolavgchecker = 1;
					}
				}

				if (DateTime.Now.ToString("hhmm") == "0700" && toolavgchecker == 1)
				{
					/*
					dbAccess_Select everydaySetting = new dbAccess_Select()
					{
						Query = $"SET ARITHABORT ON; " +
						$"Select * From dbo.vw_Facility_ToolCuttingTime"//T_02는 공통코드로 fanuc focas 라이브러리를 통해 컨트롤이 가능한 설비를 의미
					};
					foreach (DataRow r in everydaySetting.AccSelect().Rows)
					{
						if(r["CuttingTime"].ToString() == "fail" || r["CuttingTime"].ToString() == "")
						{
							Console.WriteLine("fail");
						}
						else
						{
							try
							{
								toolcriterion.Add(r["FacilityNo"].ToString() + r["ProgramNo"].ToString() + r["PTN"].ToString(), int.Parse(r["CuttingTime"].ToString()));
							}
							catch
							{
								Console.WriteLine("이미 추가된 키입니다." + r["FacilityNo"].ToString() + r["ProgramNo"].ToString() + r["PTN"].ToString());
							}							
						}
					}
					*/
					dbAccess_InsertUpdate dataclear = new dbAccess_InsertUpdate()
					{
						Query = $"delete from Facility_ToolCuttingTime where basedate = '{DateTime.Now.AddDays(-7):yyyyMMdd}'"
					};
					dataclear.InsertUpdate();
					toolavgchecker = 0;
				}
				#endregion

				for (int i = 0; i < ConfigurationManager.AppSettings.Count; i++) //설비 수만큼 반복
				{
					pot1.facilityHandle = fanucfn.fanuc_getHandle(ConfigurationManager.AppSettings.Get(i).ToString());
					//5616 + 60*x
					Console.WriteLine("-----------------------------VM0" + (i + 1));
					for (int j = 0; j <= 29; j++)
					{
						int memorystart = 5604 + 60 * j;
						Console.WriteLine("--" + j + "------" + memorystart);
						string PTN = fanucfn.samplePTN(pot1.facilityHandle, (ushort)memorystart, (ushort)(memorystart + 5), 3);

						memorystart += 7234;
						string Current = fanucfn.sample(pot1.facilityHandle, (ushort)memorystart, (ushort)(memorystart + 1), 1); //atc to atc

						memorystart += 2;
						string CuttingTime = fanucfn.sample(pot1.facilityHandle, (ushort)memorystart, (ushort)(memorystart + 3), 3); //Cutting Time
						Console.WriteLine("PTN : " + PTN + " -- Current : " + Current);

						if (currentTool[i, j] != Current) //기존에 있는
						{
							short ret;
							string serialno;
							Focas1.ODBM macro = new Focas1.ODBM();
							ret = Focas1.cnc_rdmacro(pot1.facilityHandle, 699, 10, macro); //커스텀매크로변수에서 무슨파레트 사용하는지 확인
							try
							{
								if (string.Format("{0}", Math.Abs(macro.mcr_val)).Substring(0, 5) == "10000") //1번에서 사용시 921참조
								{
									ret = Focas1.cnc_rdmacro(pot1.facilityHandle, 921, 10, macro);
									serialno = string.Format("{0}", Math.Abs(macro.mcr_val)).Substring(0, 7);
								}
								else if (string.Format("{0}", Math.Abs(macro.mcr_val)).Substring(0, 5) == "20000") //2번에서 사용시 941참조
								{
									ret = Focas1.cnc_rdmacro(pot1.facilityHandle, 941, 10, macro);
									serialno = string.Format("{0}", Math.Abs(macro.mcr_val)).Substring(0, 7);
								}
								else
								{
									serialno = "fail";
								}
							}
							catch
							{
								serialno = "fail";
							}
							if (startcurrent.ContainsKey($"{i}+{j}"))
							{
								Console.WriteLine("Act Tool!");
							}
							else
							{
								startcurrent.Add($"{i}+{j}", serialno);
							}
								

						}
						else if (currentTool[i, j] == Current)
						{
							if (startcurrent.ContainsKey($"{i}+{j}"))
							{
								string basedate;
								string serialno = startcurrent[$"{i}+{j}"];
								if (DateTime.Now.Hour < 7)
								{
									basedate = DateTime.Now.AddDays(-1).ToString("yyyyMMdd");
								}
								else
								{
									basedate = DateTime.Now.ToString("yyyyMMdd");
								}

								if (pot1.prgnum(pot1.facilityHandle).Length < 3 && CuttingTime != "" && serialno != "fail")//프로그램 넘버는 2자리수다
								{
									try
									{
										insertToolData($"VM0{(i + 1)}", serialno, pot1.prgnum(pot1.facilityHandle), PTN, CuttingTime, Current, basedate);
									}
									catch (Exception e)
									{
										Console.WriteLine("기존에 존재하지 않았던 툴입니다." + e);
										insertToolData($"VM0{(i + 1)}", serialno, pot1.prgnum(pot1.facilityHandle), PTN, CuttingTime, Current, basedate);
									}
								}
								startcurrent.Remove($"{i}+{j}");
							}
							else
							{
								Console.WriteLine("No Act Tool");
							}
						}
						currentTool[i, j] = Current;
					}
					Focas1.cnc_freelibhndl(pot1.facilityHandle);
				}
				Thread.Sleep(1500);
			}
			#endregion

			void insertToolData(string 설비번호, string 시리얼, string 프로그램번호, string PTN, string 가공시간, string ATCtoAtc, string basedate)
			{
				dbAccess_InsertUpdate PmcInsert = new dbAccess_InsertUpdate()
				{
					Query = $"Insert into Facility_ToolCuttingTime(FacilityNo, ShortSerial, ProgramNo, PTN, CuttingTime, ATCtoATC, EventDateTime, BaseDate) Values('{설비번호}', '{시리얼}', '{프로그램번호}', '{PTN}', '{가공시간}', '{ATCtoAtc}', '{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}', '{basedate}')"
				};
				PmcInsert.InsertUpdate();
			}
		}
		#endregion
	}
}
