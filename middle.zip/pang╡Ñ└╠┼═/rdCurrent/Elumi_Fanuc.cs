﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//외부 라이브러리
using ED_getPLC_001.lib.Focas; //화낙fanuc Focas 라이브러리

//내부 참조
using dbControl; //db 커넥션
using System.Data;

namespace ED_getPLC_001.Facility_Controll //pang데이터 수집용
{
	class Fanuc_Control
	{
		public string FacilityNo { get; set; } = "";
		public string FacilityIP { get; set; } = "";
		public ushort FacilityHandle { get; set; } = 0;
	}

	class ED_Fanuc_result : Fanuc_Control
	{
		public string inputPallet_699 { get; set; } = "";
		public string plag_890 { get; set; } = "";
		public string currentProgramNo_904 { get; set; } = "";
		public string Op10serial_921 { get; set; } = "";
		public string Op20serial_941 { get; set; } = "";
	}

	class Elumi_Fanuc_fn
	{
		//화낙설비의 데이터를 컨트롤 할때 handle을 취득해야한다. 핸들 취득함수
		public ushort fanuc_getHandle(string ip, int FacilityNo) //알람위해 매개변수 추가
		{
			ushort handle;
			short ret;

			ret = Focas1.cnc_allclibhndl3(ip, 8193, 1, out handle);

			if (ret != 0) //ret은 에러메세지를 저장한다. 그리고 0은 정상일때 출력되는 값이다.
			{
				handle = 0;
				dbControl.dbAccess_InsertUpdate FacilityStateUpdate = new dbControl.dbAccess_InsertUpdate()
				{
					Query = $"Update dbo.Facility_AlarmState set FacilityAlarm = 'A', EventDateTime = '{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}' Where FacilityNo = 'VM0{FacilityNo}'"
				};
				FacilityStateUpdate.InsertUpdate();
			}
			else
			{
				dbControl.dbAccess_InsertUpdate FacilityStateUpdate = new dbControl.dbAccess_InsertUpdate()
				{
					Query = $"Update dbo.Facility_AlarmState set FacilityAlarm = 'N', EventDateTime = '{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}' Where FacilityNo = 'VM0{FacilityNo}'"
				};
				FacilityStateUpdate.InsertUpdate();
			}

			return handle;
		}

		public short sample(ushort h, ushort start, ushort end)//tool data 취득
		{
			short ret, idx;
			short adr_type, data_type;
			ushort length;

			adr_type = 9;                     // In case that kind of PMC address is T
			data_type = 0;                    // In case that type of PMC data is Byte
			length = (ushort)(8 + (end - start + 1));
			//(ushort)(end - start);
			Focas1.IODBPMC iODBPMC = new Focas1.IODBPMC();
			ret = Focas1.pmc_rdpmcrng(h, adr_type, data_type, start, end, length, iODBPMC);
			if (ret == Focas1.EW_OK)
			{
				for (idx = 0; idx <= 4; idx++)
				{
					Console.WriteLine("#{0:d4}  0x{1:X2}", idx, iODBPMC.idata[idx]);
				}
			}
			else
			{
				Console.WriteLine("ERROR!({0})", ret);
			}
			return (ret);
		}

		public ED_Fanuc_result[] fanuc_settingFacility()
		{
			int FacilityCount = 0;
			int roopcount = 0;
			ED_Fanuc_result[] return_FanucSetting;

			try
			{
				dbAccess_Select dbAccess1 = new dbAccess_Select()
				{
					Query = $"SET ARITHABORT ON; " +
							$"Select FacilityNo, IpAddr From dbo.Facility2(NOLOCK) where FacilityTypeCd = 'T_02'"//T_02는 공통코드로 fanuc focas 라이브러리를 통해 컨트롤이 가능한 설비를 의미
				};
				FacilityCount = dbAccess1.AccSelect().Rows.Count;

				return_FanucSetting = new ED_Fanuc_result[FacilityCount];
				for (int i = 0; i < FacilityCount; i++)
				{
					return_FanucSetting[i] = new ED_Fanuc_result();
				}

				foreach (DataRow r in dbAccess1.AccSelect().Rows)
				{
					return_FanucSetting[roopcount].FacilityNo = r["FacilityNo"].ToString();
					return_FanucSetting[roopcount].FacilityIP = r["IpAddr"].ToString();
					roopcount++;
				}
			}
			catch
			{
				Console.WriteLine("Failed to get Facility data");
				return_FanucSetting = new ED_Fanuc_result[0];
			}

			return return_FanucSetting;
		}
	}
}
