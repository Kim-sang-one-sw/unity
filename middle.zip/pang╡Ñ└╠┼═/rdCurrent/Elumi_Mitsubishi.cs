﻿//시스템 및 ms
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//외부 라이브러리
using ActUtlTypeLib; //미스비시plc MX Component 라이브러리

//내부 참조
using ED_FacilityONOFF;


namespace ED_FacilityONOFF.Facility_Controll
{
	class Elumi_Mitsubishi
	{
		ActUtlTypeClass ActUtl { get; set; } //커넥션 같은 개념 해당 pc에서 MX Component를 활용하여 

		public int OpenStatusCode { get; set; }

		public void setConnection(int LogicalStationNumber)
		{
			int hexLogicalStationNumber;
			ActUtl = new ActUtlTypeClass();

			if (!GetIntValue(LogicalStationNumber, out hexLogicalStationNumber))
			{
				Console.WriteLine("Conversion Fail");
				return;
			}
			ActUtl.ActLogicalStationNumber = hexLogicalStationNumber;
		}
		//divce 영역번호, size 시작부터 사이즈까지, hexyex 영역이 16진수인가?, result 결과
		public string getPLCData(string dvice, int size, bool hexyes)
		{
			OpenStatusCode = ActUtl.Open();

			if (OpenStatusCode != 0)
			{
				ActUtl.Close();
				return "fail";
			}

			int iReturnCode;                //Return code
			String szDeviceName = "";       //List data for 'DeviceName'
			int iNumberOfData = 0;          //Data for 'DeviceSize'
			short[] arrDeviceValue;         //Data for 'DeviceValue'
			int iNumber;                    //Loop counter
			System.String[] arrData;        //Array for 'Data'
			string result = "";


			szDeviceName = String.Join("\n", dvice);

			int iDiviceSize = size;
			if (!GetIntValue(iDiviceSize, out iNumberOfData))
			{
				Console.WriteLine("divice size error");
				ActUtl.Close();
				return "fail";
			}
			arrDeviceValue = new short[iNumberOfData];

			//ReadDeviceBlock2 method  PLC영역의 값을 읽어온다.
			try
			{
				//The ReadDeviceBlock2 method is executed. 예외처리
				iReturnCode = ActUtl.ReadDeviceBlock2(szDeviceName, iNumberOfData, out arrDeviceValue[0]);
			}
			catch (Exception exception) //높은확률로 문자열이 맞지 않을때 에러를 도출한다.
			{
				Console.WriteLine(exception + "::get data fail");
				ActUtl.Close();
				return "fail";
			}
			//The return code of the method is displayed by the hexadecimal.

			string StatusCode = String.Format("0x{0:x8}", iReturnCode);

			//return			
			//When the ReadDeviceRandom2 method is succeeded, display the read data.
			if (iReturnCode == 0)
			{
				//Assign the array for the read data.
				arrData = new System.String[iNumberOfData];

				//Copy the read data to the 'arrData'.
				for (iNumber = 0; iNumber < iNumberOfData; iNumber++)
				{
					if (hexyes)
					{
						arrData[iNumber] = changeAssembl(Convert.ToString(arrDeviceValue[iNumber], 16));
						result += arrData[iNumber];
					}
					else
					{
						string checklength = arrDeviceValue[iNumber].ToString();
						if (checklength.Length == 1)
						{
							checklength = "0" + checklength;
						}

						arrData[iNumber] = checklength;
						result += arrData[iNumber];
					}
				}
				ActUtl.Close();
				return result;
			}
			else
			{
				ActUtl.Close();
				return "fail";
			}
		}

		#region "Processing of getting 32bit integer from TextBox" -- GetIntValue
		private bool GetIntValue(int isimpleint, out int iGottenIntValue)
		{
			iGottenIntValue = 0;
			//Get the value as 32bit integer from a TextBox
			try
			{
				iGottenIntValue = Convert.ToInt32(isimpleint);
			}

			//Exception processing
			catch (Exception exExcepion)
			{
				Console.WriteLine(exExcepion + "변환실패");
				return false;
			}

			//Normal End
			return true;
		}
		#endregion

		private string changeAssembl(string exch)
		{
			if (exch.Length == 4)
			{
				return (Convert.ToChar(Convert.ToInt32(exch.Substring(2), 16))
					+ Convert.ToChar(Convert.ToInt32(exch.Substring(0, 2), 16)).ToString());
			}
			else
			{
				return exch;
			}
		}

		private string changeBinary(int exch)
		{
			return (Convert.ToString(exch, 2));
		}

		public void setPLCData(string dvice, int size, string value)
		{
			OpenStatusCode = ActUtl.Open();

			if (OpenStatusCode != 0)
			{
				ActUtl.Close();
				return;
			}

			int iReturnCode;                //Return code
			String lpszLabelName = "";      //List data for 'LabelName'
			int iNumberOfData = 0;          //Data for 'DeviceValue'
			short arrDeviceValue;         //Data for 'DeviceValue'
			int iSizeOfIntArray;            //

			lpszLabelName = String.Join("\n", dvice);

			//Check the 'DeviceSize'.(If succeeded, the value is gotten.)
			if (!GetIntValue(size, out iNumberOfData))
			{
				//If failed, this process is end.
				ActUtl.Close();
				return;
			}
			iSizeOfIntArray = dvice.Length;

			try
			{
				arrDeviceValue = Convert.ToInt16(value);
			}


			catch
			{
				Console.WriteLine("PLC Input Data error");
				ActUtl.Close();
				return;
			}

			//
			//Processing of WriteDeviceBlock2 method
			//
			try
			{
				//The WriteDeviceRandom2 method is executed.
				iReturnCode = ActUtl.WriteDeviceBlock2(lpszLabelName,
																iNumberOfData,
																arrDeviceValue);
			}

			//Exception processing			
			catch
			{
				Console.WriteLine("PLC Input Data error");
				ActUtl.Close();
				return;
			}

			Console.WriteLine(String.Format("0x{0:x8} [HEX]", iReturnCode) + "PLC input");
			ActUtl.Close();
			//The return code of the method is displayed by the hexadecimal.
		}


	}
}
