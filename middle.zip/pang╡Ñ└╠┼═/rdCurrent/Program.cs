﻿using System.Configuration;
using System.Threading;

using dbControl;

using ED_getPLC_001.Facility_Controll;

using ED_getPLC_001.lib.Focas;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ED_FacilityONOFF.Facility_Controll;

namespace rdCurrent
{
	class Program
	{
		static void Main(string[] args)
		{
			#region focas마샬링 변수
			Focas1.ODBM macro = new Focas1.ODBM();
			Focas1.IODBTIME CycleTime = new Focas1.IODBTIME();
			#endregion
			
			#region 데이터
			string[,] currentTool = new string[8, 30];
			Dictionary<string, string> startcurrent = new Dictionary<string, string>();
			Dictionary<string, string> Programno = new Dictionary<string, string>();
			Dictionary<string, string> Serialno = new Dictionary<string, string>();
			Dictionary<string, string> StartDateTime = new Dictionary<string, string>();
			Elumi_Fanuc_fn fanucfn = new Elumi_Fanuc_fn();


			Elumi_Mitsubishi ALine_Mitsubishi = new Elumi_Mitsubishi();
			Elumi_Mitsubishi BLine_Mitsubishi = new Elumi_Mitsubishi();
			Elumi_Mitsubishi In_Stocker = new Elumi_Mitsubishi();
			Elumi_Mitsubishi Out_Stocker = new Elumi_Mitsubishi();
			#region 초기 값 설정
			ALine_Mitsubishi.setConnection(1); //PLC 커넥션 연결
			BLine_Mitsubishi.setConnection(2); //PLC 커넥션 연결
			In_Stocker.setConnection(3); //PLC 커넥션 연결
			Out_Stocker.setConnection(4); //PLC 커넥션 연결
			#endregion

			#region th2 화낙 설비관련 데이터 get

			ED_Fanuc_result[] _ED_Fanuc_Results = fanucfn.fanuc_settingFacility();
			short ret;
			int[] beforeTime = new int[_ED_Fanuc_Results.Length];
			int[] fanucRunCheck = new int[_ED_Fanuc_Results.Length];
			int[] fanucRunningCheck = new int[_ED_Fanuc_Results.Length];

			string[] RB = new string[4]; //나머지설비들 ..로봇4
			string[] MA = new string[2]; //나머지설비들 ..중간자동화2
			string[] WM = new string[2]; //나머지설비들 ..세척기2 
			string CMM3;

			//eventCal.ActiveSet();
			Thread th2 = new Thread(() =>
			{
				int FirstCheck = 1;
				while (true)
				{
					
					if (ALine_Mitsubishi.getPLCData("R6004", 1, false) == "01")
					{
						FacilityStateDB_Update("RB03", "A");
					}
					else
					{
						FacilityStateDB_Update("RB03", "N");
					}

					if (BLine_Mitsubishi.getPLCData("R6004", 1, false) == "01")
					{
						FacilityStateDB_Update("RB02", "A");
					}
					else
					{
						FacilityStateDB_Update("RB02", "N");
					}

					if (In_Stocker.getPLCData("R6004", 1, false) == "01")
					{
						FacilityStateDB_Update("RB01", "A");
					}
					else
					{
						FacilityStateDB_Update("RB01", "N");
					}

					if (Out_Stocker.getPLCData("R6004", 1, false) == "01")
					{
						FacilityStateDB_Update("RB04", "A");
					}
					else
					{
						FacilityStateDB_Update("RB04", "N");
					}

					//Console.WriteLine(ALine_Mitsubishi.getPLCData("R6060", 1, false));
					//Console.WriteLine(BLine_Mitsubishi.getPLCData("R6060", 1, false));

					try
					{
						RB[0] = binReverse(Convert.ToString(int.Parse(ALine_Mitsubishi.getPLCData("R6000", 1, false)), 2)); //RB02
					}
					catch
					{
						RB[0] = "0";
					}

					try
					{
						RB[1] = binReverse(Convert.ToString(int.Parse(BLine_Mitsubishi.getPLCData("R6000", 1, false)), 2)); //RB02
					}
					catch
					{
						RB[1] = "0";
					}
					try
					{
						RB[2] = binReverse(Convert.ToString(int.Parse(ALine_Mitsubishi.getPLCData("R6000", 1, false)), 2)); //RB03
					}
					catch
					{
						RB[2] = "0";
					}
					try
					{
						RB[3] = binReverse(Convert.ToString(int.Parse(Out_Stocker.getPLCData("R6000", 1, false)), 2)); //RB04 
					}
					catch
					{
						RB[3] = "0";
					}


					try
					{
						MA[0] = binReverse(Convert.ToString(int.Parse(ALine_Mitsubishi.getPLCData("R6030", 1, false)), 2)); //MA01
					}
					catch
					{
						MA[0] = "0";
					}
					try
					{
						MA[1] = binReverse(Convert.ToString(int.Parse(BLine_Mitsubishi.getPLCData("R6030", 1, false)), 2)); //MA02 
					}
					catch
					{
						MA[1] = "0";
					}
					try
					{
						WM[0] = binReverse(Convert.ToString(int.Parse(ALine_Mitsubishi.getPLCData("R6060", 1, false)), 2)); //WM01 
					}
					catch
					{
						WM[0] = "0";
					}
					try
					{
						WM[1] = binReverse(Convert.ToString(int.Parse(BLine_Mitsubishi.getPLCData("R6060", 1, false)), 2)); //WM02 
					}
					catch
					{
						WM[1] = "0";
					}
					try
					{
						CMM3 = binReverse(Convert.ToString(int.Parse(Out_Stocker.getPLCData("R6080", 1, false)), 2)); //CM01 
					}
					catch
					{
						CMM3 = "0";
					}

					Console.WriteLine(CMM3 +"--" );

					for (int i = 0; i < CMM3.Length; i++) //cmm 무조건 3자리는 나옴 앞에 3자리는 순서대로 123cmm 자동 상태임
					{
						if(i < 3)
						{
							if (CMM3.Substring(i, 1) == "1")
							{
								FacilityStateDB_Update($"CM0{(i + 1)}", "A");
							}
							else
							{
								FacilityStateDB_Update($"CM0{(i + 1)}", "N");
							}
						}

						if (i > 6)
						{
							if (CMM3.Substring(i, 1) == "1")
							{
								FacilityAlarmStateDB_Update($"CM0{(i - 5)}", "A"); //알람
							}
							else
							{
								FacilityAlarmStateDB_Update($"CM0{(i - 5)}", "N"); //non알람
							}
						}
						else
						{
							FacilityAlarmStateDB_Update($"CM01", "N"); //non알람
							FacilityAlarmStateDB_Update($"CM02", "N"); //non알람
							FacilityAlarmStateDB_Update($"CM03", "N"); //non알람
						}
					}


					for (int i = 0; i < 4; i++) //설비별 동일한 로직 적용
					{
						if (RB[i].Length > 9)
						{
							if (RB[i].Substring(9, 1) == "1")
							{
								FacilityAlarmStateDB_Update($"RB0{(i + 1)}", "A");
							}
							else
							{
								FacilityAlarmStateDB_Update($"RB0{(i + 1)}", "N");
							}
						}
						else
						{
							FacilityAlarmStateDB_Update($"RB0{(i + 1)}", "N");
						}
					}


					for (int i = 0; i < 2; i++) //설비별 동일한 로직 적용
					{
						if(MA[i].Length > 4) //자동운전중은 5bit 자리부터다
						{
							if(MA[i].Substring(4, 1) == "1")
							{
								FacilityStateDB_Update($"MA0{(i + 1)}", "A");
							}
							else
							{
								FacilityStateDB_Update($"MA0{(i + 1)}", "A");
							}
						}
						else
						{
							FacilityStateDB_Update($"MA0{(i + 1)}", "N");
							Console.WriteLine("err");
						}

						if (MA[i].Length > 8)
						{
							if (MA[i].Substring(9, 1) == "1")
							{
								FacilityAlarmStateDB_Update($"MA0{(i + 1)}", "A");
							}
							else
							{
								FacilityAlarmStateDB_Update($"MA0{(i + 1)}", "N");
							}
						}
						else
						{
							FacilityAlarmStateDB_Update($"MA0{(i + 1)}", "N");
						}
					}

					for (int i = 0; i < 2; i++) //설비별 동일한 로직 적용 
					{
						if (WM[i].Length > 4) //자동운전중은 5bit 자리부터다
						{
							if (WM[i].Substring(4, 1) == "1")
							{
								FacilityStateDB_Update($"WM0{(i + 1)}", "A");
							}
							else
							{
								FacilityStateDB_Update($"WM0{(i + 1)}", "A");
							}
						}
						else
						{
							FacilityStateDB_Update($"WM0{(i + 1)}", "N");
							Console.WriteLine("err");
						}

						if (WM[i].Length > 8)
						{
							if (WM[i].Substring(9, 1) == "1")
							{
								FacilityAlarmStateDB_Update($"WM0{(i + 1)}", "A");
							}
							else
							{
								FacilityAlarmStateDB_Update($"WM0{(i + 1)}", "N");
							}
						}
						else
						{
							FacilityAlarmStateDB_Update($"WM0{(i + 1)}", "N");
						}

					}

					//Console.WriteLine(binReverse(Convert.ToString(int.Parse(BLine_Mitsubishi.getPLCData("R6060", 1, false)), 2))); 
					ALine_Mitsubishi.getPLCData("R6060", 1, false);
					BLine_Mitsubishi.getPLCData("R6060", 1, false);
					
					for (int i = 0; i < _ED_Fanuc_Results.Length; i++)//화낙설비 데이터 가져오고 풀고 실행
					{
						_ED_Fanuc_Results[i].FacilityHandle = fanucfn.fanuc_getHandle(_ED_Fanuc_Results[i].FacilityIP, (i+1));

						ret = Focas1.cnc_rdtimer(_ED_Fanuc_Results[i].FacilityHandle, 3, CycleTime);

						if (FirstCheck == 1)
						{
							beforeTime[i] = CycleTime.msec;
						}
						else
						{
							if (beforeTime[i] == CycleTime.msec)
							{
								beforeTime[i] = CycleTime.msec;
								FacilityStateDB_Update($"VM0{(i + 1)}", "N");
							}
							else
							{
								beforeTime[i] = CycleTime.msec;
								FacilityStateDB_Update($"VM0{(i + 1)}", "A");
							}
						}
						Focas1.cnc_freelibhndl(_ED_Fanuc_Results[i].FacilityHandle);
					}
					FirstCheck = 0;


					//가동비가동  end
					//알람 start


					Thread.Sleep(1000);
				}
			});
			
			#endregion
			th2.Start();
			#endregion

			Thread th3 = new Thread(() => 
			{
				dbAccess_Select get_result_Qty = new dbAccess_Select()
				{
					Query = $"Select * From dbo.Facility_Result(NOLOCK) where basedate = '{DateTime.Now.ToString("yyyyMMdd")}'"
				};

			});




			//함수

			string binReverse(string text)//plc 바이너리 코드 
			{
				char[] charArray = text.ToCharArray();
				Array.Reverse(charArray);
				return new string(charArray);
			}

			void FacilityStateDB_Update(string 설비명, string 상태)
			{
				dbControl.dbAccess_InsertUpdate FacilityStateUpdate = new dbControl.dbAccess_InsertUpdate()
				{
					Query = $"Update dbo.Facility_State set FacilityState = '{상태}', EventDateTime = '{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}' Where FacilityNo = '{설비명}'"
				};
				FacilityStateUpdate.InsertUpdate();
			}

			void FacilityAlarmStateDB_Update(string 설비명, string 상태)
			{
				dbControl.dbAccess_InsertUpdate FacilityStateUpdate = new dbControl.dbAccess_InsertUpdate()
				{
					Query = $"Update dbo.Facility_AlarmState set FacilityAlarm = '{상태}', EventDateTime = '{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}' Where FacilityNo = '{설비명}'"
				};
				FacilityStateUpdate.InsertUpdate();
			}



		}
	}
}
