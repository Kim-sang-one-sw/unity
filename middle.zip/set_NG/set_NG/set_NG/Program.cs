﻿using System;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading.Tasks;
using dbControl;

namespace set_NG
{
	class Program
	{
		static void Main(string[] args)
		{
			Dictionary<string, string> DefectHistory = new Dictionary<string, string>();

			while (true)
			{
				dbAccess_InsertUpdate setDelete_NG = new dbAccess_InsertUpdate()
				{
					Query = "delete from dbo.Facility_Defect where processStatus = 'NG'"
				};
				setDelete_NG.InsertUpdate();

				dbAccess_Select SearchNG = new dbAccess_Select()
				{
					Query = $"SET ARITHABORT ON; Select * from dbo.Facility_Result(NOLOCK) where (BaseDate = '{DateTime.Now.Date.AddDays(-1).ToString("yyyyMMdd")}' OR BaseDate = '{DateTime.Now.Date.ToString("yyyyMMdd")}') and ProcessStatus = 'NG'"
				};
				foreach (DataRow r in SearchNG.AccSelect().Rows)
				{
					try
					{
						if (!DefectHistory.ContainsKey(r["LongSerialNo"].ToString().Substring(12, 8)))
						{
							DefectHistory.Add(r["LongSerialNo"].ToString().Substring(12, 8), r["ItemCode"].ToString());
						}
						Console.WriteLine("get defect history" + r["LongSerialNo"].ToString());
						Console.WriteLine("test---:" + r["LongSerialNo"].ToString().Substring(12, 8));
					}
					catch
					{
						Console.WriteLine("Result get err!!");
					}
				}

				Console.WriteLine("start");
				dbAccess_Select2 SearchRow = new dbAccess_Select2()
				{
					Query = $"SET ARITHABORT ON; select PROD_CD, PROD_DT, SHIFT, ITNBR, MC_NO from dbo.P_PROD_SCRAP_HI(NOLOCK) where cell_no='L1' and (prod_dt = '{DateTime.Now.Date.AddDays(-2).ToString("yyyyMMdd")}' or prod_dt = '{DateTime.Now.Date.AddDays(-1).ToString("yyyyMMdd")}' or prod_dt= '{DateTime.Now.Date.ToString("yyyyMMdd")}')"
				};
				foreach (DataRow r in SearchRow.AccSelect().Rows)
				{
					try
					{
						if (DefectHistory.ContainsKey(r["PROD_CD"].ToString().Substring(0, 8)) == false) //기존에 있는 불량정보
						{
							setNG(r["PROD_CD"].ToString().Substring(0, 7), r["PROD_DT"].ToString(), r["SHIFT"].ToString(), r["ITNBR"].ToString(), "VM0" + r["MC_NO"].ToString());

							Console.WriteLine("result up" + r["PROD_CD"].ToString());
						}
					}
					catch
					{
						Console.WriteLine("Defect get error");
					}

					Thread.Sleep(1000);
				}
				Thread.Sleep(300000);
				DefectHistory.Clear();
			}

			void setNG(string ShortSerial, string basedate, string ShiftCd, string ItemCode, string FacilityNo) //3. 불량정보 연동하기로 판된 데이터 처리
			{
				string beforeLongSerial = "";
				string beforeProcessStatus = "Empty";

				Console.WriteLine("--------------");
				Console.WriteLine(ShortSerial + "-1");
				Console.WriteLine(basedate + "-2");
				Console.WriteLine(ShiftCd + "-3");
				Console.WriteLine(ItemCode + "-4");
				Console.WriteLine(FacilityNo + "-5");
				Console.WriteLine("--------------\n");


				dbAccess_Select getResult_Process = new dbAccess_Select()
				{
					Query = $"SET ARITHABORT ON; Select * from dbo.Facility_Result(NOLOCK) where ShortSerialNo = '{ShortSerial}' and itemCode = '{ItemCode}' and FacilityNo = '{FacilityNo}'"
				};
				Console.WriteLine(getResult_Process.Query);
				foreach (DataRow r in getResult_Process.AccSelect().Rows)
				{
					beforeLongSerial = r["LongSerialNo"].ToString();
					beforeProcessStatus = r["ProcessStatus"].ToString();
				}

				if (beforeProcessStatus != "Empty")
				{
					if (beforeProcessStatus == "Miss")//만약 미처리 이면
					{
						Console.WriteLine("miss?");
						dbAccess_InsertUpdate setMiss_NG = new dbAccess_InsertUpdate()
						{
							Query = $"SET ARITHABORT ON; Update dbo.Facility_MissSerial Set Remark = '사후불량처리', PostYn = 1 where LongSerialNo = '{beforeLongSerial}'"
						};
						setMiss_NG.InsertUpdate();

						dbAccess_InsertUpdate setNG_Miss = new dbAccess_InsertUpdate()
						{
							Query = $"SET ARITHABORT ON; Insert into dbo.Facility_Defect(LongSerialNo, BaseDate, ShiftCd, TeamCode, ItemCode, FacilityNo, ProcessStatus, MissYn) Values('{beforeLongSerial}', '{basedate}',  '{ShiftCd}', dbo.fn_TeamCode_ByBaseDateAndShiftCd('{basedate}', '{ShiftCd}'), '{ItemCode}', '{FacilityNo}', '{beforeProcessStatus}', 1)"
						};
						setNG_Miss.InsertUpdate();
					}
					else if (beforeProcessStatus == "NG")
					{
						Console.WriteLine("이미등록된 NG");
					}
					else
					{
						dbAccess_InsertUpdate setNG_Miss = new dbAccess_InsertUpdate()
						{
							Query = $"SET ARITHABORT ON; Insert into dbo.Facility_Defect(LongSerialNo, BaseDate, ShiftCd, TeamCode, ItemCode, FacilityNo, ProcessStatus, MissYn) Values('{beforeLongSerial}', '{basedate}',  '{ShiftCd}', dbo.fn_TeamCode_ByBaseDateAndShiftCd('{basedate}', '{ShiftCd}'), '{ItemCode}', '{FacilityNo}', '{beforeProcessStatus}', 0)"
						};
						setNG_Miss.InsertUpdate();
					}

					dbAccess_InsertUpdate setRemeasure_NG = new dbAccess_InsertUpdate()
					{
						Query = $"SET ARITHABORT ON; Update dbo.Facility_Remeasure Set confirm = '불량' where LongSerialNo = '{beforeLongSerial}'"
					};
					setRemeasure_NG.InsertUpdate();

					dbAccess_InsertUpdate setResult_Miss = new dbAccess_InsertUpdate()
					{
						Query = $"SET ARITHABORT ON; Update dbo.Facility_Result Set ProcessStatus = 'NG', BaseDate = '{basedate}', ShiftCd = '{ShiftCd}' where LongSerialNo = '{beforeLongSerial}'"
					};
					setResult_Miss.InsertUpdate();

				}

			}
		}
	}
}
