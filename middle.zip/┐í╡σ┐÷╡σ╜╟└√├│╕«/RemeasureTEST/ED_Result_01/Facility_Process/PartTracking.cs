﻿using dbControl;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Configuration;
using ActiveService;
using System.Data;

namespace ED_Result_01.Facility_Process
{
	class PartTracking
	{
		
		short ret;

		Elumi_Fanuc fanuc_set = new Elumi_Fanuc();

		#region DB엑세스관련 함수
		public void DB_inputSerial(string LongSerial)
		{
			string StartDate = DateTime.Now.ToString("yyyyMMddHHmmss");
			dbAccess_Insert dbAccess1 = new dbAccess_Insert()
			{
				Query = $"SET ARITHABORT ON; Insert Into dbo.Facility_Result(FacilityNo,LongSerialNo,ShortSerialNo,ItemCode,ProcessStatus,StartDateTime) Values('VM0{LongSerial.Substring(19, 1)}', '{LongSerial}', '{LongSerial.Substring(12, 7)}', '{LongSerial.Substring(0, 9)}', 'Start', '{StartDate}')"
			};
			try
			{
				Console.WriteLine(dbAccess1.Query + "적용 쿼리");
				dbAccess1.Insert();
			}
			catch (Exception ee)
			{
				
				
				
				Console.WriteLine(ee + "\n input DB LOGIC ERROR!");
			}
		}


		public void DB_inputRe(string LongSerial)
		{
			string StartDate = DateTime.Now.ToString("yyyyMMddHHmmss");

			dbAccess_Insert dbAccess1 = new dbAccess_Insert()
			{
				Query = $"SET ARITHABORT ON; Insert Into dbo.Facility_Result(FacilityNo,LongSerialNo,ShortSerialNo,ItemCode,ProcessStatus,StartDateTime) Values('VM0{LongSerial.Substring(19, 1)}', '{LongSerial}', '{LongSerial.Substring(12, 7)}', '{LongSerial.Substring(0, 9)}', 'Start', '{StartDate}')"
			};
			try
			{
				Console.WriteLine(dbAccess1.Query + "적용 쿼리");
				dbAccess1.Insert();
			}
			catch (Exception ee)
			{



				Console.WriteLine(ee + "\n input DB LOGIC ERROR!");
			}
		}

		public void DB_inputMiss(string LongSerial)
		{
			string LastProcess = "";
			dbAccess_Select Load_Setting = new dbAccess_Select()
			{
				Query = $"Select * From dbo.Facility_Result (NOLOCK) Where LongSerialNo = '{LongSerial}'"
			};
			foreach (DataRow r in Load_Setting.AccSelect().Rows)
			{
				LastProcess = (r["ProcessStatus"].ToString());
			}//프로그램 재가동시 해당 날짜의 데이터는 복구가능

			string EventDate = DateTime.Now.ToString("yyyyMMddHHmmss");
			string enddate = DateTime.Now.ToString("yyyyMMddHHmmss");
			string basedate;
			string shiftcd;
			if (enddate.Substring(8, 1) == "0")
			{
				if (int.Parse(enddate.Substring(9, 5)) < 70000)
				{
					basedate = DateTime.Now.AddDays(-1).ToString("yyyyMMdd");//ens
					shiftcd = "ENS";
				}
				else
				{
					basedate = enddate.Substring(0, 8);//eds
					shiftcd = "EDS";
				}
			}
			else
			{
				if (int.Parse(enddate.Substring(8, 6)) > 190000)//19
				{
					shiftcd = "ENS";
				}
				else
				{
					shiftcd = "EDS";
					basedate = enddate.Substring(0, 8);//ens 해당로우는 밖으로 뺀다
				}
				basedate = enddate.Substring(0, 8);//ens 해당로우는 밖으로 뺀다
			}
			dbAccess_Insert dbAccess1 = new dbAccess_Insert()
			{
				Query = $"SET ARITHABORT ON; Insert Into dbo.Facility_MissSerial(FacilityNo,LongSerialNo,BaseDate,ShiftCd,LastProcess,TeamCode,ItemCode) Values('VM0{LongSerial.Substring(19, 1)}', '{LongSerial}', '{basedate}', '{shiftcd}', '{LastProcess}', 'dbo.fn_TeamCode_ByBaseDateAndShiftCd('{basedate}', '{shiftcd}')', '{LongSerial.Substring(12, 7)}')"
			};
			try
			{
				Console.WriteLine(dbAccess1.Query + "적용 쿼리");
				dbAccess1.Insert();
			}
			catch (Exception ee)
			{
				Console.WriteLine(ee + "\n inputMIss DB LOGIC ERROR!");
			}
		}

		public void DB_updateSerial(string LongSerial, string Status)
		{
			if(Status != "END")
			{
				dbAccess_Insert dbAccess1 = new dbAccess_Insert()
				{
					Query = $"Update dbo.Facility_Result Set ProcessStatus= '{Status}' Where LongSerialNo = '{LongSerial}'"
				};
				try
				{
					Console.WriteLine(dbAccess1.Query + "적용 쿼리");
					dbAccess1.Insert();
				}
				catch (Exception ee)
				{
					Console.WriteLine(ee + "update DB LOGIC ERROR!" + Status);
				}
			}
			else
			{
				string enddate = DateTime.Now.ToString("yyyyMMddHHmmss");
				string basedate;
				string shiftcd;
				if (enddate.Substring(8, 1) == "0")
				{
					if (int.Parse(enddate.Substring(9, 5)) < 70000)
					{
						basedate = DateTime.Now.AddDays(-1).ToString("yyyyMMdd");//ens
						shiftcd = "ENS";
					}
					else
					{
						basedate = enddate.Substring(0, 8);//eds
						shiftcd = "EDS";
					}
				}
				else
				{
					if (int.Parse(enddate.Substring(8, 6)) > 190000)//19
					{
						shiftcd = "ENS";
					}
					else
					{
						shiftcd = "EDS";
						basedate = enddate.Substring(0, 8);//ens 해당로우는 밖으로 뺀다
					}
					basedate = enddate.Substring(0, 8);//ens 해당로우는 밖으로 뺀다
				}

				dbAccess_Insert dbAccess1 = new dbAccess_Insert()
				{
					Query = $"Update dbo.Facility_Result Set ProcessStatus= '{Status}', EndDateTime = '{enddate}', ShiftCd = '{shiftcd}', BaseDate = '{basedate}'  Where LongSerialNo = '{LongSerial}' "
				};
				try
				{
					Console.WriteLine(dbAccess1.Query + "적용 쿼리");
					dbAccess1.Insert();
				}
				catch (Exception ee)
				{
					Console.WriteLine(ee + "update DB LOGIC ERROR!" + Status);
				}
			}

		}
		#endregion
	}
}