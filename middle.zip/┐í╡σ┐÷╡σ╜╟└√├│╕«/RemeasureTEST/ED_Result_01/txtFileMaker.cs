﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ED_Result_01.txtFileMaker
{
	/*
	class txtFileMaker
	{
	}
	*/

	public class txtMaker
	{
		public void CerateFile(string serial, string StartTime, string EndTime, string cutting, string programNo)
		{

			string mcPath = serial.Substring(19, 1);
			string serialPath = serial.Substring(12, 10) + "211";

			string path = @"C:\FTP\MC" + mcPath + "\\" + serialPath + ".txt";

			if (!File.Exists(path))
			{
				using (File.Create(path))
				{
					Console.WriteLine("생성완료");
				}
			}
			else
			{
				Console.WriteLine($"{serial} -- 이미 존재하는 시리얼");
			}
			TxtWrite(path, serial, StartTime, EndTime, cutting, programNo);
		}

		public void TxtWrite(string path, string serial, string StartTime, string EndTime, string cutting, string programNo)
		{
			StreamWriter writer = File.AppendText(path);

			//글자수 예외처리

			writer.WriteLine("MC_TIME");
			writer.WriteLine("CURRENT-PROGRAM " + programNo); //partno 에서 프로그램번호 확인해서 참조
			writer.WriteLine("CELL-NO 21 1");

			if (StartTime.Length > 8)
			{
				writer.WriteLine("START-DATE " + StartTime.Substring(0, 8));
				writer.WriteLine("START-TIME " + StartTime.Substring(8));
			}
			else
			{
				writer.WriteLine("START-DATE " + 0);
				writer.WriteLine("START-TIME " + 0);
			}


			if (EndTime.Length > 8)
			{
				writer.WriteLine("END-DATE " + EndTime.Substring(0, 8));
				writer.WriteLine("END-TIME " + EndTime.Substring(8));
			}
			else
			{
				writer.WriteLine("END-DATE " + 0);
				writer.WriteLine("END-TIME " + 0);
			}

			writer.WriteLine("MC-NUMBER " + serial.Substring(19, 1));
			writer.WriteLine("PALLET-NUMBER " + serial.Substring(21, 1)); //파레트넘버 직접 참조 //적용 007 @KSO
			writer.WriteLine("CUTTING-TIME " + cutting);
			writer.WriteLine("PART-NO1 " + serial.Substring(0, 9));
			writer.WriteLine("SERIAL-NO " + serial.Substring(12, 7));

			writer.Close();
		}
	}
}
