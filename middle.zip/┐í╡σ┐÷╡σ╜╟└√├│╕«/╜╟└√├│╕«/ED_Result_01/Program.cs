﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ActUtlTypeLib;
using System.Threading;
using dbControl;
using ActiveService;

using System.Configuration;
using System.Data;

using ED_Result_01.Facility_Setup;
using ED_Result_01.Facility_Process;
using ED_Result_01.txtFileMaker;

namespace ED_Result_01
{
	class Program
	{

		static Elumi_Mitsubishi ALine_Mitsubishi = new Elumi_Mitsubishi();
		static Elumi_Mitsubishi BLine_Mitsubishi = new Elumi_Mitsubishi();
		static Elumi_Mitsubishi In_Stocker = new Elumi_Mitsubishi();
		static Elumi_Mitsubishi Out_Stocker = new Elumi_Mitsubishi();

		#region focas마샬링 변수
		static Focas1.ODBM macro = new Focas1.ODBM();
		static Focas1.IODBTIME CycleTime = new Focas1.IODBTIME();
		#endregion

		struct fanucFacility
		{
			public string f_ip;

			public ushort handle;

			public string inputPallet_699;
			public string plag_890;
			public string currentProgramNo_904;
			public string op10serial_921;
			public string op20serial_941;
		};

		static Dictionary<string, int> InputSerial = new Dictionary<string, int>(); //투입된 모든 시리얼 관리

		static Dictionary<string, int> RemeasureSerial = new Dictionary<string, int>();

		static string[] L1_Process = new string[8];
		

		static string[] MC_serial = new string[8];
		static string[] MC_Start = new string[8];
		static string[] MC_End = new string[8];

		static string[] MC_op10Serial = new string[8]; // op10 
		static string[] MC_MaSerial = new string[2];// 중간 자동화		
		static string[] MC_op20Serial = new string[8]; // op20
		static string[] MC_CMM = new string[6]; // CMM
		static string[] MC_END = new string[2];// 중간 자동화		

		static void Main(string[] args)
		{
			L1_Process[0] = "Start";
			L1_Process[1] = "OP10";
			L1_Process[2] = "OP10 END";
			L1_Process[3] = "Middle";
			L1_Process[4] = "OP20";
			L1_Process[5] = "OP20 END";
			L1_Process[6] = "CMM";
			L1_Process[7] = "END";

			ALine_Mitsubishi.setConnection(1); //PLC 커넥션 연결
			BLine_Mitsubishi.setConnection(2); //PLC 커넥션 연결
			In_Stocker.setConnection(3); //PLC 커넥션 연결
			Out_Stocker.setConnection(4); //PLC 커넥션 연결

			PartTracking partTracking = new PartTracking();

			//만약 프로그램 종료시 복구
			dbAccess_Select Load_Setting = new dbAccess_Select()
			{
				Query = $"Select * From dbo.Facility_Result (NOLOCK) Where ProcessStatus != 'END' and StartDateTime like '{DateTime.Now.ToString("yyyyMMdd")}%'"
			};
			foreach (DataRow r in Load_Setting.AccSelect().Rows)
			{
				if(Array.IndexOf(L1_Process, r["ProcessStatus"].ToString()) != -1)
				{
					if (InputSerial.ContainsKey(BLine_Mitsubishi.getPLCData("R6100", 12, true)) == false) //이미 투입된 시리얼인지 확인 Code : A-Line input
					{
						InputSerial.Add((r["LongSerialNo"].ToString()), Array.IndexOf(L1_Process, r["ProcessStatus"].ToString()));
					}
				}
			}//프로그램 재가동시 해당 날짜의 데이터는 복구가능
			fanucFacility[] ed_fanuc = new fanucFacility[8];

			#region op20투입 시리얼 영역
			string[] input_op20_serial = new string[8];
			for (int i = 0; i < input_op20_serial.Length; i++)
			{
				input_op20_serial[i] = "0";
			}
			#endregion

			#region th1 공정과정
			Thread th1 = new Thread(() =>
			{
				while (true)
				{
					#region 투입

					if (InputSerial.ContainsKey(ALine_Mitsubishi.getPLCData("R6100", 12, true)) == false) //이미 투입된 시리얼인지 확인 Code : A-Line input
					{
						dbAccess_Select _Select = new dbAccess_Select()
						{
							Query = $"SET ARITHABORT ON; select * from dbo.Facility_Result(NOLOCK) where LongSerialNo = '{ALine_Mitsubishi.getPLCData("R6100", 12, true)}'"
						};
						Console.WriteLine(_Select.Query + "--적용쿼리");
						try
						{
							if (_Select.AccSelect().Rows.Count == 0)
							{
								InputSerial.Add(ALine_Mitsubishi.getPLCData("R6100", 12, true), 0);
								partTracking.DB_inputSerial(ALine_Mitsubishi.getPLCData("R6100", 12, true));
							}
							else
							{
								Console.WriteLine("??");
							}
						}
						catch
						{
							Console.WriteLine("ACCSelect is null");
						}

					}

					if (InputSerial.ContainsKey(BLine_Mitsubishi.getPLCData("R6100", 12, true)) == false) //이미 투입된 시리얼인지 확인 Code : A-Line input
					{
						dbAccess_Select _Select = new dbAccess_Select()
						{
							Query = $"SET ARITHABORT ON; select * from dbo.Facility_Result(NOLOCK) where LongSerialNo = '{BLine_Mitsubishi.getPLCData("R6100", 12, true)}'"
						};
						Console.WriteLine(_Select.Query + "--적용쿼리");
						try
						{
							if ((_Select.AccSelect().Rows.Count == 0) && (_Select.AccSelect() != null))
							{
								InputSerial.Add(BLine_Mitsubishi.getPLCData("R6100", 12, true), 0);
								partTracking.DB_inputSerial(BLine_Mitsubishi.getPLCData("R6100", 12, true));
							}
						}
						catch
						{
							Console.WriteLine("AccSelect is null!!");
						}

					}
					#endregion

					#region OP10 투입
					MC_op10Serial[0] = ALine_Mitsubishi.getPLCData("R6120", 12, true); //MC1 op10 투입
					MC_op10Serial[1] = ALine_Mitsubishi.getPLCData("R6160", 12, true); //MC2 op10 투입
					MC_op10Serial[2] = ALine_Mitsubishi.getPLCData("R6200", 12, true); //MC3 op10 투입
					MC_op10Serial[3] = ALine_Mitsubishi.getPLCData("R6240", 12, true); //MC4 op10 투입
					MC_op10Serial[4] = BLine_Mitsubishi.getPLCData("R6120", 12, true); //MC5 op10 투입
					MC_op10Serial[5] = BLine_Mitsubishi.getPLCData("R6160", 12, true); //MC6 op10 투입
					MC_op10Serial[6] = BLine_Mitsubishi.getPLCData("R6200", 12, true); //MC7 op10 투입
					MC_op10Serial[7] = BLine_Mitsubishi.getPLCData("R6240", 12, true); //MC8 op10 투입

					for (int i = 0; i < MC_op10Serial.Length; i++)
					{
						if (InputSerial.ContainsKey(MC_op10Serial[i]))
						{
							if (InputSerial[MC_op10Serial[i]] < 1)
							{
								MissSerial(MC_op10Serial[i], 1); //이전 시리얼의 공정 파악

								InputSerial[MC_op10Serial[i]] = 1;
								partTracking.DB_updateSerial(MC_op10Serial[i], L1_Process[1]);
								FanucInputOp(MC_op10Serial[i], 921); //921 메모리는 op10 시리얼이다
								partTracking.DB_updateWorking(MC_op10Serial[i]);
							}
						}
					}
					#endregion

					#region 중간자동화 투입
					MC_MaSerial[0] = ALine_Mitsubishi.getPLCData("R6280", 12, true); //A-Line 중간자동화
					MC_MaSerial[1] = BLine_Mitsubishi.getPLCData("R6280", 12, true); //B-Line 중간자동화
					for (int i = 0; i < MC_MaSerial.Length; i++)
					{
						if (InputSerial.ContainsKey(MC_MaSerial[i]))
						{
							if (InputSerial[MC_MaSerial[i]] < 3)
							{
								MissSerial(MC_MaSerial[i], 3);

								InputSerial[MC_MaSerial[i]] = 3;
								partTracking.DB_updateSerial(MC_MaSerial[i], L1_Process[3]);
							}
						}
					}


					#endregion

					#region OP20 투입
					MC_op20Serial[0] = ALine_Mitsubishi.getPLCData("R6140", 12, true); //MC1 op20 투입
					MC_op20Serial[1] = ALine_Mitsubishi.getPLCData("R6180", 12, true); //MC2 op20 투입
					MC_op20Serial[2] = ALine_Mitsubishi.getPLCData("R6220", 12, true); //MC3 op20 투입
					MC_op20Serial[3] = ALine_Mitsubishi.getPLCData("R6260", 12, true); //MC4 op20 투입
					MC_op20Serial[4] = BLine_Mitsubishi.getPLCData("R6140", 12, true); //MC5 op20 투입
					MC_op20Serial[5] = BLine_Mitsubishi.getPLCData("R6180", 12, true); //MC6 op20 투입
					MC_op20Serial[6] = BLine_Mitsubishi.getPLCData("R6220", 12, true); //MC7 op20 투입
					MC_op20Serial[7] = BLine_Mitsubishi.getPLCData("R6260", 12, true); //MC8 op20 투입


					for (int i = 0; i < MC_op20Serial.Length; i++)
					{
						if (InputSerial.ContainsKey(MC_op20Serial[i]))
						{
							if (InputSerial[MC_op20Serial[i]] < 4)
							{
								MissSerial(MC_op20Serial[i], 4);

								InputSerial[MC_op20Serial[i]] = 4;
								partTracking.DB_updateSerial(MC_op20Serial[i], L1_Process[4]);

								FanucInputOp(MC_op20Serial[i], 941); //941 메모리는 op20 시리얼이다
								partTracking.DB_updateWorking(MC_op20Serial[i]);
							}
						}
					}
					#endregion

					#region CMM

					MC_CMM[0] = Out_Stocker.getPLCData("R6360", 12, true); //CMM
					MC_CMM[1] = Out_Stocker.getPLCData("R6380", 12, true); //CMM
					MC_CMM[2] = Out_Stocker.getPLCData("R6300", 12, true); //CMM
					MC_CMM[3] = Out_Stocker.getPLCData("R6420", 12, true); //CMM
					MC_CMM[4] = Out_Stocker.getPLCData("R6440", 12, true); //CMM
					MC_CMM[5] = Out_Stocker.getPLCData("R6460", 12, true); //CMM

					for (int i = 0; i < MC_CMM.Length; i++)
					{
						if (InputSerial.ContainsKey(MC_CMM[i]))
						{
							if (InputSerial[MC_CMM[i]] < 6)
							{
								MissSerial(MC_CMM[i], 6);

								InputSerial[MC_CMM[i]] = 6;
								partTracking.DB_updateSerial(MC_CMM[i], L1_Process[6]);
							}
						}
					}
					#endregion

					#region END
					MC_END[0] = Out_Stocker.getPLCData("R6320", 12, true); //END
					Console.WriteLine(Out_Stocker.getPLCData("R6320", 12, true));
					MC_END[1] = Out_Stocker.getPLCData("R6340", 12, true); //END
					Console.WriteLine(Out_Stocker.getPLCData("R6340", 12, true));
					for (int i = 0; i < MC_END.Length; i++)
					{
						if (InputSerial.ContainsKey(MC_END[i]))
						{
							if (InputSerial[MC_END[i]] < 7)
							{
								MissSerial(MC_END[i], 7);

								InputSerial[MC_END[i]] = 7;
								partTracking.DB_updateSerial(MC_END[i], L1_Process[7]); //end

								setPerformanceFile(MC_END[i]); //파일드랍

								InputSerial.Remove(MC_END[i]); //시리얼 삭제
							}
						}

					}
					#endregion
				}
			}
			);

			//{ IsBackground = true };
			#endregion

			#region th2 CuttingTime and ProgramNo

			Thread th2 = new Thread(() =>
			{
				short ret;
				Elumi_Fanuc fanuc_fn = new Elumi_Fanuc();
				while (true)
				{
					for (int i = 0; i < 8; i++)
					{
						ed_fanuc[i].f_ip = ConfigurationManager.AppSettings.Get(i);

						ed_fanuc[i].handle = fanuc_fn.fanuc_getHandle(ed_fanuc[i].f_ip);

						ret = Focas1.cnc_rdmacro(ed_fanuc[i].handle, 699, 10, macro);
						ed_fanuc[i].inputPallet_699 = string.Format("{0}", Math.Abs(macro.mcr_val));

						ret = Focas1.cnc_rdmacro(ed_fanuc[i].handle, 890, 10, macro);
						ed_fanuc[i].plag_890 = string.Format("{0}", Math.Abs(macro.mcr_val));

						/*
						ret = Focas1.cnc_rdmacro(ed_fanuc[i].handle, 904, 10, macro);
						ed_fanuc[i].currentProgramNo_904 = string.Format("{0}", Math.Abs(macro.mcr_val));
						*/
						ed_fanuc[i].currentProgramNo_904 = fanuc_fn.prgnum(ed_fanuc[i].handle);

						ret = Focas1.cnc_rdmacro(ed_fanuc[i].handle, 921, 10, macro);
						ed_fanuc[i].op10serial_921 = string.Format("{0}", Math.Abs(macro.mcr_val));

						ret = Focas1.cnc_rdmacro(ed_fanuc[i].handle, 941, 10, macro);
						ed_fanuc[i].op20serial_941 = string.Format("{0}", Math.Abs(macro.mcr_val));

						ret = Focas1.cnc_rdtimer(ed_fanuc[i].handle, 3, CycleTime);
						/*
						 * 시작--
						 * 플래그가 1이면
							* CycleTime을 읽어가고
							* 파레트 번호가 1이면
								* OP10에 Seirial 번호로 db에서 찾아서 CycleTime 저장
								* status 'OP20대기'로 변경
								* 플래그 0으로 변경
							* 파레트 번호가 2이면
								* OP20에 Seirial 번호로 db에서 찾아서 CycleTime 저장
								* status '실적대기'로 변경
								* 플래그 0으로 변경
						 * --종료

						 * update dbo.Facility_Result Set OP10 = 1, Status = 'OP20' Where ShortSerialNo = '4'
						 * update dbo.Facility_Result Set OP20 = 1, Status = 'END' Where ShortSerialNo = '4'
						 */
						#region 주석로직
						if (ed_fanuc[i].plag_890.Substring(0, 1) == "1")
						{
							int OP_cycletime = (CycleTime.minute * 60) + (CycleTime.msec / 1000);

							if (ed_fanuc[i].inputPallet_699.Substring(0, 4) == "1000")
							{
								try
								{
									dbAccess_Insert dbAccess1 = new dbAccess_Insert()
									{
										Query = $"SET ARITHABORT ON; Update dbo.Facility_Result Set OP10CuttingTime = {OP_cycletime}, OP10ProgramNo = '{ed_fanuc[i].currentProgramNo_904}', ProcessStatus = 'OP10 END' Where ShortSerialNo = '{ed_fanuc[i].op10serial_921.Substring(0, 7)}' and FacilityNo = 'VM0{(i + 1)}' and ProcessStatus != 'END' and itemCode = (select itemcode from dbo.Item_ProgramNo where programno = '{ed_fanuc[i].currentProgramNo_904}')"//mc -> vm
										//설비번호
									};
									dbAccess1.Insert();
									Console.WriteLine(dbAccess1.Query + ":u쿼리 op10");
									ret = Focas1.cnc_wrmacro(ed_fanuc[i].handle, 890, 10, 0, 0);
								}
								catch (Exception ee)
								{
									Console.WriteLine(ee + "DB LOGIC ERROR!");
								}
							}
							else if (ed_fanuc[i].inputPallet_699.Substring(0, 4) == "2000")
							{

								try
								{
									dbAccess_Insert dbAccess1 = new dbAccess_Insert()
									{
										Query = $"SET ARITHABORT ON; Update dbo.Facility_Result Set OP20CuttingTime = {OP_cycletime}, OP20ProgramNo = '{ed_fanuc[i].currentProgramNo_904}', ProcessStatus = 'OP20 END' Where ShortSerialNo = '{ed_fanuc[i].op20serial_941.Substring(0, 7)}' and FacilityNo = 'VM0{(i + 1)}' and ProcessStatus != 'END' and itemCode = (select itemcode from dbo.Item_ProgramNo where programno = '{ed_fanuc[i].currentProgramNo_904}')"//mc -> vm
																																																																															   //설비번호
									};
									dbAccess1.Insert();
									Console.WriteLine(dbAccess1.Query + ":u쿼리 op20");
									ret = Focas1.cnc_wrmacro(ed_fanuc[i].handle, 890, 10, 0, 0);
								}
								catch (Exception ee)
								{
									Console.WriteLine(ee + "DB LOGIC ERROR!");
								}
							}
							else
							{
								Console.WriteLine("CMV ERROR: 699ERROR" + " : MC0" + (i + 1));
							}
						}
						#endregion
						ret = Focas1.cnc_freelibhndl(ed_fanuc[i].handle);
					}
				}
			});
			//{ IsBackground = true };
			#endregion

			#region th3 
			
			Thread th3 = new Thread(() =>
			{
				string ReameasureNO = "";
				string getSerial;
				while (true)
				{
					getSerial = Out_Stocker.getPLCData("R6480", 12, true);
					if (ReameasureNO != getSerial)
					{
						if(getSerial != "fail")
						{
							ReameasureNO = getSerial;

							partTracking.DB_inputRe(ReameasureNO);
						}
					}
				}
			});
			
			#endregion

			th1.Start();
			th2.Start();
			th3.Start();

			//함수목록

			void MissSerial(string LongSerial, int State) //이전 시리얼의 공정을 파악하여 공정이 늦으면 미처리(Miss)상태로 변경
			{
				int beforeSerialNo = int.Parse(LongSerial.Substring(17, 2)) - 1;
				string beforeserial;
				if (beforeSerialNo.ToString().Length == 1)
				{
					beforeserial = LongSerial.Substring(0, 17) + "0" + beforeSerialNo.ToString() + LongSerial.Substring(19, 5);
				}
				else
				{
					beforeserial = LongSerial.Substring(0, 17) + beforeSerialNo.ToString() + LongSerial.Substring(19, 5);
				}

				if (InputSerial.ContainsKey(beforeserial))
				{
					if (InputSerial[beforeserial] < State) //
					{
						Console.WriteLine(beforeserial + "miss 시리얼");
						partTracking.DB_inputMiss(beforeserial);
						partTracking.DB_updateSerial(beforeserial, "Miss");						
						InputSerial.Remove(beforeserial);
					}
				}
			}

			void FanucInputOp(string LongSerial, short cmvno)
			{
				Elumi_Fanuc fanuc_set = new Elumi_Fanuc();

				int f = int.Parse(LongSerial.Substring(19, 1));
				ushort fhandle = fanuc_set.fanuc_getHandle(ConfigurationManager.AppSettings.Get((f - 1)));
				short ret = Focas1.cnc_wrmacro(fhandle, cmvno, 10, int.Parse(LongSerial.Substring(12, 7)), 0);
				Focas1.cnc_freelibhndl(fhandle);
			}

			void setPerformanceFile(string Serial)
			{
				txtMaker ResultFile = new txtMaker();

				int Cutting = 0;
				string StartTime = "0";
				string EndTime = "0";
				string ProgramNo = "0";
				dbAccess_Select _Select = new dbAccess_Select()
				{
					Query = $"SET ARITHABORT ON; select * from dbo.Facility_Result(NOLOCK) where LongSerialNo = '{Serial}'"
				};
				Console.WriteLine(_Select.Query + "--적용쿼리");
				try
				{
					if ((_Select.AccSelect().Rows.Count != 0) && (_Select.AccSelect() != null))
					{
						foreach (DataRow r in _Select.AccSelect().Rows)
						{
							//if(r["OP10CuttingTime"].ToString() == "END")
							try
							{
								Cutting += int.Parse(r["OP10CuttingTime"].ToString());
							}
							catch
							{
								Console.WriteLine("op10 Cutting time 에러");
							}

							try
							{
								Cutting += int.Parse(r["OP20CuttingTime"].ToString());
							}
							catch
							{
								Console.WriteLine("op20 Cutting time 에러");
							}

							StartTime = r["StartDateTime"].ToString();

							if (StartTime.Length < 11)
							{
								StartTime = "00000000000000";
								Console.WriteLine("StartTime error");
							}

							EndTime = r["EndDateTime"].ToString();

							if (EndTime.Length < 11)
							{
								EndTime = "00000000000000";
								Console.WriteLine("EndTime error");
							}

							try
							{
								ProgramNo = r["OP10ProgramNo"].ToString();
							}
							catch
							{
								ProgramNo = "0";
								Console.WriteLine("op10programNo error");
							}
						}
						ResultFile.CerateFile(Serial, StartTime, EndTime, Cutting.ToString(), ProgramNo);
					}
					else
					{
						Console.WriteLine("DB_Select ERROR!!");
					}
				}
				catch(Exception ee)
				{
					Console.WriteLine("data err" + ee + "\n" + _Select.Query);
				}
			}
		}


	}
}
